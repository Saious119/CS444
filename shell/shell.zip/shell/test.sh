this 'is a' & command of some > kind
"this should" /be/a ; list/of --commands ;

{ this | block | contains } > a < large >> pipeline ; and -a /list

MEANWHILE


IN



CANADA
