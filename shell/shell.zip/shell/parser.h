#ifndef PARSER_H
#define PARSER_H

#include "shtypes.h"

struct cmd *parse();

#endif
