#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h> 
#include <sys/wait.h>
#include <stdlib.h>

int fork1(void);
