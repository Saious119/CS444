#ifdef XV6
#include "user.h"
#else
#include <string.h>
#include <stdlib.h>
#endif
